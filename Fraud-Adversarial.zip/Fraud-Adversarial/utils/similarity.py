"""
语义相似度计算模块
基于 SemAttack (NAACL 2022) 论文思想

使用 Chinese Sentence-BERT 计算语义相似度
"""

def cosine_similarity(vec1, vec2):
    """计算余弦相似度"""
    import numpy as np
    dot_product = np.dot(vec1, vec2)
    norm1 = np.linalg.norm(vec1)
    norm2 = np.linalg.norm(vec2)
    if norm1 == 0 or norm2 == 0:
        return 0.0
    return dot_product / (norm1 * norm2)


def semantic_similarity(text1, text2, model=None):
    """
    计算两个文本的语义相似度

    论文 Formula 1:
    Sim(x, x') = (Embedding(x) · Embedding(x')) / (||Embedding(x)|| · ||Embedding(x')||)

    参数:
        text1: 原始文本
        text2: 改写文本
        model: Sentence-BERT模型，为None时使用简化版

    返回:
        相似度分数 [0, 1]
    """
    if model is None:
        # 简化版：基于长度变化
        len_ratio = min(len(text1), len(text2)) / max(len(text1), len(text2), 1)
        return len_ratio

    # 完整版：使用Sentence-BERT
    try:
        from sentence_transformers import SentenceTransformer
        if isinstance(model, str):
            model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')

        emb1 = model.encode([text1])[0]
        emb2 = model.encode([text2])[0]
        return cosine_similarity(emb1, emb2)
    except Exception as e:
        print(f"相似度计算失败: {e}")
        # 回退到简化版
        len_ratio = min(len(text1), len(text2)) / max(len(text1), len(text2), 1)
        return len_ratio


# 论文中的判定规则
SIMILARITY_THRESHOLDS = {
    'semantic': 0.90,    # 词语替换，语义变化小
    'paraphrase': 0.85,  # 句子改写，允许更大变化
    'noise': 0.95,       # 字符扰动，语义几乎不变
}
