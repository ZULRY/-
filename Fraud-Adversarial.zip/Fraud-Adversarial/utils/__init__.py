"""
工具模块
"""
from .similarity import semantic_similarity, cosine_similarity, SIMILARITY_THRESHOLDS
