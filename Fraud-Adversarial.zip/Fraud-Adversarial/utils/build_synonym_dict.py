"""
同义词词林解析器
自动检测文件编码，解析哈工大同义词词林
"""
import os
import codecs
import joblib

SYNONYM_FILE = r"E:\语言大作业\HIT-IRLab-同义词词林（扩展版）_full_2005.3.3.txt"
OUTPUT_FILE = r"E:\语言大作业\Fraud-Adversarial\data\fraud_synonyms.pkl"

def detect_encoding(file_path):
    """检测文件编码"""
    encodings_to_try = [
        ('gbk', 'GBK简体中文'),
        ('gb2312', 'GB2312简体中文'),
        ('gb18030', 'GB18030简体中文'),
        ('utf-8', 'UTF-8'),
        ('big5', 'Big5繁体'),
        ('cp950', 'CP950繁体'),
        ('iso-8859-1', 'Latin-1'),
    ]

    # 首先尝试用chardet检测
    try:
        import chardet
        with open(file_path, 'rb') as f:
            raw = f.read(10000)
            result = chardet.detect(raw)
            print(f"chardet检测: {result}")
            if result['encoding'] and result['confidence'] > 0.7:
                return result['encoding']
    except ImportError:
        pass

    # 手动尝试
    for enc, name in encodings_to_try:
        try:
            with codecs.open(file_path, 'r', encoding=enc, errors='strict') as f:
                # 尝试读取几行
                for i in range(3):
                    line = f.readline()
                # 如果成功，检查是否包含中文
                if any('\u4e00' <= c <= '\u9fff' for c in line):
                    print(f"成功使用编码: {name} ({enc})")
                    return enc
        except:
            continue

    return 'gbk'  # 默认

def parse_synonym_line(line):
    """解析一行同义词"""
    line = line.strip()
    if not line:
        return None

    # 格式: 编码=同义词列表 或 编码#同义词列表
    if '=' in line:
        parts = line.split('=', 1)
        words = parts[1].split()
        return words
    elif '#' in line:
        parts = line.split('#', 1)
        words = parts[1].split()
        return words
    elif '@' in line:
        parts = line.split('@', 1)
        words = parts[1].split()
        return words

    return None

def build_synonym_dict(file_path):
    """构建同义词词典"""
    encoding = detect_encoding(file_path)

    synonym_dict = {}

    with codecs.open(file_path, 'r', encoding=encoding, errors='replace') as f:
        for line in f:
            words = parse_synonym_line(line)
            if words and len(words) > 1:
                # 将所有词互为同义词
                for word in words:
                    if word not in synonym_dict:
                        synonym_dict[word] = []
                    # 添加其他词作为候选
                    for other in words:
                        if other != word and other not in synonym_dict[word]:
                            synonym_dict[word].append(other)

    return synonym_dict

def extract_fraud_synonyms(synonym_dict):
    """提取诈骗相关的同义词"""
    # 诈骗相关关键词及其同义词
    fraud_keywords = [
        '银行', '账户', '账号', '密码', '验证', '冻结',
        '转账', '支付', '操作', '身份', '核实', '异常',
        '安全', '风险', '资金', '财产', '诈骗', '欺骗',
        '中奖', '奖金', '优惠', '退款', '退货',
        '客服', '服务', '电话', '短信', '链接',
    ]

    fraud_synonyms = {}
    for kw in fraud_keywords:
        if kw in synonym_dict:
            fraud_synonyms[kw] = synonym_dict[kw]

    return fraud_synonyms

def main():
    print("=" * 60)
    print("同义词词林解析器")
    print("=" * 60)

    # 检测编码
    encoding = detect_encoding(SYNONYM_FILE)
    print(f"使用编码: {encoding}")

    # 解析词林
    print("\n正在解析词林文件...")
    synonym_dict = build_synonym_dict(SYNONYM_FILE)
    print(f"解析完成! 共 {len(synonym_dict)} 个词条")

    # 提取诈骗相关同义词
    print("\n提取诈骗相关同义词...")
    fraud_synonyms = extract_fraud_synonyms(synonym_dict)
    print(f"找到 {len(fraud_synonyms)} 个诈骗相关词条")

    # 显示示例
    print("\n示例:")
    for i, (kw, syns) in enumerate(list(fraud_synonyms.items())[:10]):
        print(f"  {kw}: {syns[:5]}...")

    # 保存
    print(f"\n保存到: {OUTPUT_FILE}")
    joblib.dump({
        'full_dict': synonym_dict,
        'fraud_dict': fraud_synonyms
    }, OUTPUT_FILE)

    # 保存为更易读的格式
    readable_file = OUTPUT_FILE.replace('.pkl', '_readable.txt')
    with open(readable_file, 'w', encoding='utf-8') as f:
        f.write("# 诈骗相关同义词词典\n")
        f.write("# 格式: 词: 同义词1, 同义词2, ...\n\n")
        for kw in sorted(fraud_synonyms.keys()):
            syns = fraud_synonyms[kw]
            f.write(f"{kw}: {', '.join(syns)}\n")
    print(f"保存可读版到: {readable_file}")

    return synonym_dict, fraud_synonyms

if __name__ == '__main__':
    main()
