"""
攻击结果可视化
生成攻击成功率、攻击方法对比等图表
"""
import os
import joblib
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # 无GUI后端

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False


def load_attack_results(results_path):
    """加载攻击结果"""
    if os.path.exists(results_path):
        return joblib.load(results_path)
    return None


def plot_asr_comparison(results_summary, save_path='results/visualize/asr_comparison.png'):
    """
    绘制攻击成功率对比柱状图
    """
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    methods = list(results_summary.keys())
    asr_values = [results_summary[m]['asr'] for m in methods]
    success_counts = [results_summary[m]['success'] for m in methods]
    total_counts = [results_summary[m]['total'] for m in methods]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    # 子图1: ASR对比
    colors = ['#3498db', '#2ecc71', '#e74c3c', '#9b59b6']
    bars1 = ax1.bar(methods, asr_values, color=colors[:len(methods)], edgecolor='black')
    ax1.set_ylabel('Attack Success Rate (%)', fontsize=12)
    ax1.set_xlabel('Attack Method', fontsize=12)
    ax1.set_title('ASR Comparison by Attack Method', fontsize=14)
    ax1.set_ylim(0, max(asr_values) * 1.2 if max(asr_values) > 0 else 10)

    # 添加数值标签
    for bar, asr in zip(bars1, asr_values):
        ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                f'{asr:.2f}%', ha='center', va='bottom', fontsize=11)

    # 子图2: 成功/失败堆叠柱状图
    failed_counts = [t - s for t, s in zip(total_counts, success_counts)]
    x = np.arange(len(methods))
    width = 0.6

    bars2 = ax2.bar(x, success_counts, width, label='Success', color='#2ecc71', edgecolor='black')
    ax2.bar(x, failed_counts, width, bottom=success_counts, label='Failed', color='#e74c3c', edgecolor='black')

    ax2.set_ylabel('Number of Samples', fontsize=12)
    ax2.set_xlabel('Attack Method', fontsize=12)
    ax2.set_title('Success vs Failed Counts', fontsize=14)
    ax2.set_xticks(x)
    ax2.set_xticklabels(methods)
    ax2.legend()

    # 添加数值标签
    for i, (s, f) in enumerate(zip(success_counts, failed_counts)):
        ax2.text(i, s/2, str(s), ha='center', va='center', fontsize=10, color='white', fontweight='bold')
        ax2.text(i, s + f/2, str(f), ha='center', va='center', fontsize=10, color='white', fontweight='bold')

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"ASR对比图已保存: {save_path}")


def plot_method_distribution(results, save_path='results/visualize/method_distribution.png'):
    """
    绘制攻击方法使用分布饼图
    """
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    # 统计各方法成功次数
    method_counts = {}
    for r in results:
        if r['success'] and r['method']:
            method = r['method'].split(' ')[0]
            method_counts[method] = method_counts.get(method, 0) + 1

    if not method_counts:
        print("没有成功攻击的数据")
        return

    labels = list(method_counts.keys())
    sizes = list(method_counts.values())
    colors = ['#3498db', '#2ecc71', '#e74c3c']

    fig, ax = plt.subplots(figsize=(8, 8))
    wedges, texts, autotexts = ax.pie(sizes, labels=labels, autopct='%1.1f%%',
                                       colors=colors[:len(labels)],
                                       explode=[0.05] * len(labels),
                                       shadow=True, startangle=90)

    for autotext in autotexts:
        autotext.set_fontsize(12)
        autotext.set_fontweight('bold')

    ax.set_title('Attack Method Distribution\n(Among Successful Attacks)', fontsize=14)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"方法分布图已保存: {save_path}")


def plot_text_length_distribution(results, save_path='results/visualize/length_distribution.png'):
    """
    绘制原文与对抗文本长度分布对比
    """
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    orig_lengths = []
    adv_lengths = []

    for r in results:
        if r['orig_text']:
            orig_lengths.append(len(r['orig_text']))
        if r['adv_text']:
            adv_lengths.append(len(r['adv_text']))

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # 直方图
    axes[0].hist(orig_lengths, bins=30, alpha=0.6, label='Original', color='#3498db', edgecolor='black')
    if adv_lengths:
        axes[0].hist(adv_lengths, bins=30, alpha=0.6, label='Adversarial', color='#e74c3c', edgecolor='black')
    axes[0].set_xlabel('Text Length (characters)', fontsize=12)
    axes[0].set_ylabel('Frequency', fontsize=12)
    axes[0].set_title('Text Length Distribution', fontsize=14)
    axes[0].legend()

    # 箱线图
    box_data = [orig_lengths] + ([adv_lengths] if adv_lengths else [])
    bp = axes[1].boxplot(box_data, labels=['Original'] + (['Adversarial'] if adv_lengths else []))
    axes[1].set_ylabel('Text Length (characters)', fontsize=12)
    axes[1].set_title('Text Length Comparison', fontsize=14)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"长度分布图已保存: {save_path}")


def plot_attack_flowchart(save_path='results/visualize/attack_flowchart.png'):
    """
    绘制攻击流程图
    """
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    fig, ax = plt.subplots(figsize=(12, 8))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 8)
    ax.axis('off')

    # 定义颜色
    colors = {
        'input': '#3498db',
        'semantic': '#2ecc71',
        'paraphrase': '#e74c3c',
        'noise': '#9b59b6',
        'output': '#f39c12',
        'decision': '#95a5a6'
    }

    def draw_box(x, y, w, h, text, color, fontsize=10):
        rect = plt.Rectangle((x-w/2, y-h/2), w, h, facecolor=color, edgecolor='black', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y, text, ha='center', va='center', fontsize=fontsize, fontweight='bold')

    def draw_arrow(x1, y1, x2, y2):
        ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                   arrowprops=dict(arrowstyle='->', color='black', lw=2))

    # 标题
    ax.text(6, 7.5, 'SemAttack Framework - Three Attack Spaces', ha='center', va='center',
           fontsize=14, fontweight='bold')

    # 输入
    draw_box(6, 6.5, 3, 0.8, 'Original Fraud Text', colors['input'])

    # 箭头到Semantic
    draw_arrow(6, 6.1, 2, 5.5)

    # Semantic Space
    draw_box(2, 5, 2.5, 0.8, 'Semantic Space\n(Synonym Replace)', colors['semantic'])
    ax.text(2, 4.3, 'Threshold: 0.90', ha='center', va='center', fontsize=9)

    # 箭头到Paraphrase
    draw_arrow(3.25, 5, 6, 5)

    # Paraphrase Space
    draw_box(6, 4.5, 3, 0.8, 'Paraphrase Space\n(LLM/Rules Rewrite)', colors['paraphrase'])
    ax.text(6, 3.8, 'Threshold: 0.85', ha='center', va='center', fontsize=9)

    # 箭头到Noise
    draw_arrow(9, 4.5, 10, 5)

    # Noise Space
    draw_box(10, 5, 2.5, 0.8, 'Noise Space\n(Char Perturbation)', colors['noise'])
    ax.text(10, 4.3, 'Threshold: 0.95', ha='center', va='center', fontsize=9)

    # 汇总到输出
    draw_arrow(10, 4.1, 6, 3)

    # Output
    draw_box(6, 2.5, 3, 0.8, 'Adversarial Text\nor None', colors['output'])

    # Legend
    legend_items = [
        (0.5, 1.5, 'Synonym Dictionary', colors['semantic']),
        (0.5, 1.0, 'LLM + Rules', colors['paraphrase']),
        (0.5, 0.5, 'Regex Patterns', colors['noise'])
    ]
    ax.text(0.5, 2, 'Attack Spaces:', fontsize=10, fontweight='bold')
    for x, y, text, color in legend_items:
        draw_box(x, y, 0.3, 0.25, '', color)
        ax.text(x + 0.8, y, text, fontsize=9)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print(f"攻击流程图已保存: {save_path}")


def generate_summary_report(results_summary, save_path='results/visualize/summary_report.txt'):
    """
    生成文字汇总报告
    """
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    with open(save_path, 'w', encoding='utf-8') as f:
        f.write("=" * 60 + "\n")
        f.write("对抗攻击实验结果汇总报告\n")
        f.write("=" * 60 + "\n\n")

        for method, stats in results_summary.items():
            f.write(f"【{method.upper()} 攻击】\n")
            f.write(f"  - 攻击样本数: {stats['total']}\n")
            f.write(f"  - 成功数: {stats['success']}\n")
            f.write(f"  - 攻击成功率 (ASR): {stats['asr']:.2f}%\n")
            f.write(f"  - 失败数: {stats['total'] - stats['success']}\n\n")

        # 计算综合指标
        total_attacks = sum(s['total'] for s in results_summary.values())
        total_success = sum(s['success'] for s in results_summary.values())
        if total_attacks > 0:
            f.write("=" * 60 + "\n")
            f.write(f"【综合统计】\n")
            f.write(f"  - 总攻击次数: {total_attacks}\n")
            f.write(f"  - 总成功次数: {total_success}\n")
            f.write(f"  - 综合ASR: {total_success/total_attacks*100:.2f}%\n")

    print(f"汇总报告已保存: {save_path}")


def visualize_from_results(results_path, output_dir='results/visualize'):
    """
    从攻击结果文件生成可视化
    """
    results = load_attack_results(results_path)
    if results is None:
        print(f"错误: 无法加载结果文件 {results_path}")
        return

    os.makedirs(output_dir, exist_ok=True)

    # 统计
    total = len(results)
    success = sum(1 for r in results if r['success'])
    failed = sum(1 for r in results if r['method'] == 'failed')
    skipped = sum(1 for r in results if r['method'] == 'skipped')

    print(f"\n{'='*60}")
    print("可视化分析")
    print(f"{'='*60}")
    print(f"总样本: {total}")
    print(f"成功: {success} ({success/total*100:.2f}%)")
    print(f"失败: {failed} ({failed/total*100:.2f}%)")
    print(f"跳过: {skipped}")

    # 生成各图表
    plot_method_distribution(results, f"{output_dir}/method_distribution.png")
    plot_text_length_distribution(results, f"{output_dir}/length_distribution.png")
    plot_attack_flowchart(f"{output_dir}/attack_flowchart.png")

    print(f"\n可视化图表已保存到: {output_dir}")


def visualize_ablation_results(ablation_summary_path, output_dir='results/visualize'):
    """
    从消融实验汇总生成对比可视化
    """
    summary = joblib.load(ablation_summary_path)
    if summary is None:
        print(f"错误: 无法加载消融实验结果")
        return

    os.makedirs(output_dir, exist_ok=True)

    # 绘制对比图
    plot_asr_comparison(summary, f"{output_dir}/ablation_asr_comparison.png")

    # 生成报告
    generate_summary_report(summary, f"{output_dir}/ablation_summary_report.txt")

    print(f"\n消融实验可视化完成，结果保存在: {output_dir}")


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', type=str, default='results/attack_results.pkl',
                        help='攻击结果文件路径')
    parser.add_argument('--ablation-summary', type=str,
                        default='results/ablation/ablation_summary.pkl',
                        help='消融实验汇总文件路径')
    parser.add_argument('--output-dir', type=str, default='results/visualize')
    args = parser.parse_args()

    print("=" * 60)
    print("攻击结果可视化")
    print("=" * 60)

    # 生成攻击流程图（总是需要）
    plot_attack_flowchart(f"{args.output_dir}/attack_flowchart.png")

    # 如果有攻击结果
    if os.path.exists(args.results):
        visualize_from_results(args.results, args.output_dir)

    # 如果有消融实验结果
    if os.path.exists(args.ablation_summary):
        visualize_ablation_results(args.ablation_summary, args.output_dir)

    print("\n可视化完成!")


if __name__ == '__main__':
    main()
