"""
数据清洗脚本
检测并移除训练集和测试集中的重复/相似样本，防止数据泄露
"""
import os
import re
import hashlib
import joblib
import pandas as pd
from collections import defaultdict


def clean_text(text):
    """清理对话文本"""
    if pd.isna(text):
        return ""
    text = str(text)
    # 去除 left: / right: 前缀
    text = text.replace('left:', '').replace('right:', '').strip()
    # 去除多余空白
    text = ' '.join(text.split())
    return text


def get_text_hash(text):
    """获取文本的哈希值"""
    return hashlib.md5(text.encode('utf-8')).hexdigest()


def find_exact_duplicates(data_list):
    """查找完全相同的样本"""
    text_hash_map = defaultdict(list)
    duplicates = []

    for i, item in enumerate(data_list):
        text = item['text']
        text_hash = get_text_hash(text)
        text_hash_map[text_hash].append((i, text))

    # 返回重复的索引（保留第一个）
    for text_hash, indices in text_hash_map.items():
        if len(indices) > 1:
            # 保留第一个，其余都是重复
            for idx, _ in indices[1:]:
                duplicates.append(idx)

    return duplicates


def find_cross_duplicates(train_data, test_data):
    """
    查找训练集和测试集之间的重复/高度相似样本
    优化版：只检查完全相同的样本，跳过耗时的Jaccard计算
    """
    # 构建测试集文本哈希映射
    test_hash_map = defaultdict(set)
    for i, item in enumerate(test_data):
        text_hash = get_text_hash(item['text'])
        test_hash_map[text_hash].add(i)

    # 检查完全相同的
    train_to_remove = set()
    test_to_remove = set()

    for i, train_item in enumerate(train_data):
        text_hash = get_text_hash(train_item['text'])
        if text_hash in test_hash_map:
            for test_idx in test_hash_map[text_hash]:
                test_to_remove.add(test_idx)
                train_to_remove.add(i)

    # 注意：省略Jaccard相似度计算，因为：
    # 1. 完全相同的样本已经构成了数据泄露
    # 2. 相似样本的判断标准主观性强
    # 3. 计算复杂度 O(n*m) 太高
    similar_pairs = []

    return train_to_remove, test_to_remove, similar_pairs


def clean_data(train_csv, test_csv, output_dir="data"):
    """
    数据清洗主函数

    步骤：
    1. 加载数据
    2. 移除训练集内部重复
    3. 移除测试集内部重复
    4. 移除训练集和测试集之间的重复/高度相似样本
    5. 保存清洗后的数据
    """
    print("=" * 60)
    print("数据清洗 - 防止数据泄露")
    print("=" * 60)

    # 1. 加载数据
    print("\n[1] 加载数据...")
    train_df = pd.read_csv(train_csv)
    test_df = pd.read_csv(test_csv)

    print(f"  训练集原始: {len(train_df)} 条")
    print(f"  测试集原始: {len(test_df)} 条")

    # 转换为标准格式
    train_data = []
    for idx, row in train_df.iterrows():
        text = clean_text(row.get('specific_dialogue_content', ''))
        if not text:
            continue
        label = 1 if row.get('is_fraud', False) else 0
        train_data.append({'text': text, 'class': label, 'orig_idx': idx})

    test_data = []
    for idx, row in test_df.iterrows():
        text = clean_text(row.get('specific_dialogue_content', ''))
        if not text:
            continue
        label = 1 if row.get('is_fraud', False) else 0
        test_data.append({'text': text, 'class': label, 'orig_idx': idx})

    print(f"  训练集处理后: {len(train_data)} 条")
    print(f"  测试集处理后: {len(test_data)} 条")

    # 2. 移除训练集内部重复
    print("\n[2] 检测训练集内部重复...")
    train_dup = find_exact_duplicates(train_data)
    print(f"  发现训练集重复: {len(train_dup)} 条")

    # 3. 移除测试集内部重复
    print("\n[3] 检测测试集内部重复...")
    test_dup = find_exact_duplicates(test_data)
    print(f"  发现测试集重复: {len(test_dup)} 条")

    # 4. 检测训练集和测试集之间的重复
    print("\n[4] 检测训练集-测试集之间的重复...")
    train_cross, test_cross, _ = find_cross_duplicates(train_data, test_data)
    print(f"  完全相同样本: 训练集={len(train_cross)}, 测试集={len(test_cross)}")

    # 5. 创建去重后的数据
    print("\n[5] 生成清洗后的数据...")

    train_to_keep = set(range(len(train_data))) - set(train_dup) - train_cross
    test_to_keep = set(range(len(test_data))) - set(test_dup) - test_cross

    clean_train = [train_data[i] for i in sorted(train_to_keep)]
    clean_test = [test_data[i] for i in sorted(test_to_keep)]

    # 6. 统计
    train_fraud = sum(1 for d in clean_train if d['class'] == 1)
    test_fraud = sum(1 for d in clean_test if d['class'] == 1)

    print(f"\n  清洗后训练集: {len(clean_train)} 条 (诈骗: {train_fraud}, 正常: {len(clean_train) - train_fraud})")
    print(f"  清洗后测试集: {len(clean_test)} 条 (诈骗: {test_fraud}, 正常: {len(clean_test) - test_fraud})")

    # 移除 orig_idx 字段（仅用于调试）
    clean_train = [{'text': d['text'], 'class': d['class']} for d in clean_train]
    clean_test = [{'text': d['text'], 'class': d['class']} for d in clean_test]

    # 7. 保存
    os.makedirs(output_dir, exist_ok=True)
    train_path = os.path.join(output_dir, 'train_clean.pkl')
    test_path = os.path.join(output_dir, 'test_clean.pkl')

    joblib.dump(clean_train, train_path)
    joblib.dump(clean_test, test_path)

    print(f"\n  保存到: {train_path}")
    print(f"  保存到: {test_path}")

    print("\n" + "=" * 60)
    print("数据清洗完成!")
    print("=" * 60)

    return clean_train, clean_test


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--train-csv', type=str,
                        default=r"E:\语言大作业\通话数据互动策略结果\训练集结果.csv",
                        help='训练数据CSV路径')
    parser.add_argument('--test-csv', type=str,
                        default=r"E:\语言大作业\通话数据互动策略结果\测试集结果.csv",
                        help='测试数据CSV路径')
    parser.add_argument('--output-dir', type=str,
                        default="data",
                        help='输出目录')
    args = parser.parse_args()

    clean_data(args.train_csv, args.test_csv, args.output_dir)
