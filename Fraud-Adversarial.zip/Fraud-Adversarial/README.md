# 中文诈骗对话对抗攻击系统

基于 SemAttack (NAACL 2022) 论文思想，实现对诈骗对话的对抗攻击测试。

## 系统架构

```
原始诈骗对话
    │
    ▼
┌─────────────────────────────────────────────────────┐
│  三层攻击空间（按顺序尝试）                          │
├─────────────────────────────────────────────────────┤
│  1. Semantic Space（语义空间）                      │
│     - 方法：同义词替换                               │
│     - 词典：词林同义词 / 预构建子集                  │
│     - 阈值：0.90                                    │
├─────────────────────────────────────────────────────┤
│  2. Paraphrase Space（句级改写空间）                │
│     - 方法：智谱AI LLM改写（优先）/ 规则改写（备用） │
│     - 模型：glm-4.5-flash                           │
│     - 阈值：0.85                                    │
├─────────────────────────────────────────────────────┤
│  3. Noise Space（字符扰动空间）                     │
│     - 方法：正则规则扰动                             │
│     - 规则：空格插入、拼音混写、同音替换、数字替换   │
│     - 阈值：0.95                                    │
└─────────────────────────────────────────────────────┘
    │
    ▼
攻击结果：成功（诈骗→正常）/ 失败
```

## LLM 集成确认 ✓

### 1. paraphrase.py（第24-52行）- LLM调用核心代码
```python
def paraphrase_with_llm(self, text):
    """使用智谱AI进行改写"""
    response = self.llm_client.chat.completions.create(
        model="glm-4.5-flash",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=512,
        temperature=0.7
    )
```

### 2. run_attack.py（第10-11行）- API Key配置
```python
ZHIPU_API_KEY = "374a847ee1af4fe398fa3b1f681c1b8b.oppCxAznqjb0RIfs"
```

### 3. 调用优先级（paraphrase.py第108-116行）
```
if self.llm_client:
    new_text = self.paraphrase_with_llm(text)   # 优先LLM
    if success: return new_text, "llm"
else:
    new_text = self.paraphrase_with_rules(text) # 备用规则
```

## 文件结构

```
Fraud-Adversarial/
├── attack/                      # 攻击模块
│   ├── __init__.py
│   ├── semantic.py              # 语义空间攻击
│   ├── paraphrase.py            # 句级改写攻击 ← LLM集成
│   ├── noise.py                 # 字符扰动攻击
│   └── pipeline.py              # 攻击协调器
│
├── data/                        # 数据模块
│   ├── __init__.py
│   ├── train.pkl                # 原始训练数据
│   ├── test.pkl                 # 原始测试数据
│   ├── train_clean.pkl          # 清洗后训练数据
│   ├── test_clean.pkl           # 清洗后测试数据
│   ├── fraud_synonyms.pkl       # 完整同义词词典(73611词条)
│   └── targeted_synonym_dict.pkl# 预构建子集词典
│
├── models/
│   ├── tfidf_classifier.py      # TF-IDF+SVM分类器
│   └── classifier.py
│
├── utils/
│   ├── __init__.py
│   ├── similarity.py            # 语义相似度计算
│   └── build_synonym_dict.py
│
├── clean_data.py                # 数据清洗脚本
├── build_targeted_dict.py       # 预构建词典脚本
├── train.py                     # 模型训练脚本
├── run_attack.py                # 攻击运行入口 ← LLM配置
└── README.md                    # 本文档
```

## 使用方法

### 1. 数据清洗（防止数据泄露）
```bash
python clean_data.py
```
输出：`data/train_clean.pkl`, `data/test_clean.pkl`

### 2. 预构建同义词词典（加速攻击）
```bash
python build_targeted_dict.py
```
输出：`data/targeted_synonym_dict.pkl`

### 3. 运行攻击

**基础攻击（规则改写）：**
```bash
python run_attack.py --test-data data/test_clean.pkl
```

**启用LLM攻击（推荐）：**
```bash
python run_attack.py --test-data data/test_clean.pkl --use-llm
```

**启用LLM + 预构建词典（最快）：**
```bash
python run_attack.py --test-data data/test_clean.pkl --use-llm --use-targeted-dict
```

**限制样本数测试：**
```bash
python run_attack.py --test-data data/test_clean.pkl --max-samples 100 --use-llm
```

## 参数说明

| 参数 | 说明 |
|-----|------|
| `--test-data` | 测试数据路径（默认 data/test.pkl） |
| `--model` | 模型路径（默认 models/tfidf_model.pkl） |
| `--output` | 结果输出路径（默认 results/attack_results.pkl） |
| `--max-samples` | 最大样本数，0表示全部 |
| `--use-llm` | **启用智谱AI进行句级改写攻击** |
| `--use-targeted-dict` | 使用预构建的同义词子集词典 |

## 依赖安装

```bash
pip install jieba scikit-learn joblib pandas tqdm
pip install zhipuai  # 智谱AI SDK
```

## API Key 配置

在 `run_attack.py` 第11行：
```python
ZHIPU_API_KEY = "374a847ee1af4fe398fa3b1f681c1b8b.oppCxAznqjb0RIfs"
```

## 输出结果

结果保存在 `results/attack_results.pkl`，包含：
- `orig_text`: 原始文本
- `adv_text`: 对抗文本
- `method`: 使用的攻击方法 (semantic/paraphrase/noise)
- `success`: 是否成功
- `orig_pred`: 原始预测 (0=正常, 1=诈骗)
- `adv_pred`: 攻击后预测

## 评估指标

| 指标 | 计算 |
|-----|------|
| ASR | 成功数 / 总攻击数 |
| ΔAcc | 原始Acc - 对抗Acc |
| 按方法统计 | semantic / paraphrase / noise 各自成功率 |

## 注意事项

1. **LLM调用次数**：每个样本最多调用1次智谱AI
2. **速度**：LLM攻击较慢，建议先用 `--max-samples 100` 测试
3. **成本**：智谱AI API 有调用限额，注意控制测试规模
4. **备用方案**：无API时自动使用规则改写
