"""
数据加载模块
"""
import os
import joblib
import pandas as pd

DATA_DIR = os.path.dirname(os.path.abspath(__file__))

def load_csv_data(csv_path):
    """加载原始CSV数据"""
    df = pd.read_csv(csv_path)
    data = []
    for _, row in df.iterrows():
        text = str(row.get('specific_dialogue_content', ''))
        # 清理文本：去除 left: / right: 前缀
        text = text.replace('left:', '').replace('right:', '').strip()
        label = 1 if row.get('is_fraud', False) else 0
        data.append({
            'text': text,
            'class': label
        })
    return data

def load_processed_data(name):
    """加载处理后的数据"""
    path = os.path.join(DATA_DIR, f'{name}.pkl')
    if os.path.exists(path):
        return joblib.load(path)
    return None

def save_processed_data(data, name):
    """保存处理后的数据"""
    path = os.path.join(DATA_DIR, f'{name}.pkl')
    joblib.dump(data, path)
    return path

def load_synonym_dict():
    """加载同义词词典"""
    path = os.path.join(DATA_DIR, 'fraud_synonyms.pkl')
    if os.path.exists(path):
        result = joblib.load(path)
        return result.get('fraud_dict', {})
    return {}

def load_full_synonym_dict():
    """加载完整同义词词典"""
    path = os.path.join(DATA_DIR, 'fraud_synonyms.pkl')
    if os.path.exists(path):
        result = joblib.load(path)
        return result.get('full_dict', {})
    return {}

def load_targeted_synonym_dict():
    """加载针对测试集预构建的同义词子集"""
    path = os.path.join(DATA_DIR, 'targeted_synonym_dict.pkl')
    if os.path.exists(path):
        return joblib.load(path)
    return None
