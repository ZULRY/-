"""
分类器基类
"""
from abc import ABC, abstractmethod

class Classifier(ABC):
    """分类器基类"""

    @abstractmethod
    def predict(self, text):
        """预测单条文本
        返回: 0=正常, 1=诈骗
        """
        pass

    @abstractmethod
    def predict_proba(self, text):
        """预测概率
        返回: [P(正常), P(诈骗)]
        """
        pass

    @abstractmethod
    def load(self, model_path):
        """加载模型"""
        pass

    @abstractmethod
    def train(self, train_data, dev_data):
        """训练模型"""
        pass
