"""
TF-IDF + SVM 分类器
"""
import os
import joblib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC
from sklearn.pipeline import Pipeline
from models.classifier import Classifier

class TFIDFClassifier(Classifier):
    """TF-IDF + SVM 分类器"""

    def __init__(self, model_path=None):
        self.model = None
        self.vectorizer = None
        if model_path and os.path.exists(model_path):
            self.load(model_path)

    def predict(self, text):
        """预测单条文本"""
        if self.model is None:
            raise ValueError("模型未加载")
        pred = self.model.predict([text])[0]
        return int(pred)

    def predict_proba(self, text):
        """预测概率"""
        if self.model is None:
            raise ValueError("模型未加载")
        # SVM没有predict_proba，使用decision_function
        decision = self.model.decision_function([text])[0]
        # 简单转换为概率
        prob = 1 / (1 + np.exp(-decision))
        return [1 - prob, prob]

    def load(self, model_path):
        """加载模型"""
        data = joblib.load(model_path)
        self.model = data['model']
        self.vectorizer = data.get('vectorizer')

    def save(self, model_path):
        """保存模型"""
        os.makedirs(os.path.dirname(model_path), exist_ok=True)
        joblib.dump({
            'model': self.model,
            'vectorizer': self.vectorizer
        }, model_path)

    def train(self, train_data, dev_data=None):
        """训练模型"""
        # 提取文本和标签
        train_texts = [item['text'] for item in train_data]
        train_labels = [item['class'] for item in train_data]

        # 创建TF-IDF + SVM pipeline
        self.model = Pipeline([
            ('tfidf', TfidfVectorizer(
                max_features=10000,
                ngram_range=(1, 2),  # 使用1-gram和2-gram
                min_df=2,
                max_df=0.95
            )),
            ('svm', SVC(
                kernel='linear',
                C=1.0,
                probability=True
            ))
        ])

        # 训练
        print("训练 TF-IDF + SVM 分类器...")
        self.model.fit(train_texts, train_labels)

        # 在训练集上评估
        train_acc = self.model.score(train_texts, train_labels)
        print(f"训练集准确率: {train_acc:.4f}")

        # 在验证集上评估
        if dev_data:
            dev_texts = [item['text'] for item in dev_data]
            dev_labels = [item['class'] for item in dev_data]
            dev_acc = self.model.score(dev_texts, dev_labels)
            print(f"验证集准确率: {dev_acc:.4f}")

        return self.model
