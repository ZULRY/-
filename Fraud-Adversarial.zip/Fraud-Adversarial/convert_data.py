"""
数据转换脚本
将原始CSV数据转换为pkl格式
"""
import os
import argparse
import pandas as pd
import joblib

def clean_text(text):
    """清理对话文本"""
    if pd.isna(text):
        return ""
    text = str(text)
    # 去除 left: / right: 前缀
    text = text.replace('left:', '').replace('right:', '').strip()
    # 去除多余空白
    text = ' '.join(text.split())
    return text

def convert_data(csv_path, output_path):
    """转换CSV数据为pkl格式"""
    print(f"读取数据: {csv_path}")
    df = pd.read_csv(csv_path)

    print(f"列名: {list(df.columns)}")
    print(f"总行数: {len(df)}")

    data = []
    for idx, row in df.iterrows():
        text = clean_text(row.get('specific_dialogue_content', ''))
        if not text:
            continue

        # 提取标签
        is_fraud = row.get('is_fraud', False)
        label = 1 if is_fraud else 0

        data.append({
            'text': text,
            'class': label,
            'index': idx
        })

    # 统计
    fraud_count = sum(1 for d in data if d['class'] == 1)
    normal_count = len(data) - fraud_count

    print(f"\n数据统计:")
    print(f"  总样本数: {len(data)}")
    print(f"  诈骗样本: {fraud_count} ({fraud_count/len(data)*100:.1f}%)")
    print(f"  正常样本: {normal_count} ({normal_count/len(data)*100:.1f}%)")

    # 保存
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    joblib.dump(data, output_path)
    print(f"\n保存到: {output_path}")

    return data

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--train-csv', type=str,
                        default=r"E:\语言大作业\通话数据互动策略结果\训练集结果.csv",
                        help='训练数据CSV路径')
    parser.add_argument('--test-csv', type=str,
                        default=r"E:\语言大作业\通话数据互动策略结果\测试集结果.csv",
                        help='测试数据CSV路径')
    parser.add_argument('--output-dir', type=str,
                        default="data",
                        help='输出目录')
    args = parser.parse_args()

    print("=" * 60)
    print("数据转换")
    print("=" * 60)

    # 转换训练数据
    train_output = os.path.join(args.output_dir, 'train.pkl')
    train_data = convert_data(args.train_csv, train_output)

    # 转换测试数据
    test_output = os.path.join(args.output_dir, 'test.pkl')
    test_data = convert_data(args.test_csv, test_output)

    print("\n" + "=" * 60)
    print("转换完成!")
    print("=" * 60)

if __name__ == '__main__':
    main()
