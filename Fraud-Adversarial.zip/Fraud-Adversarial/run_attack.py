"""
对抗攻击运行入口
"""
import os
import argparse
from data import load_processed_data, load_synonym_dict, load_targeted_synonym_dict
from models.tfidf_classifier import TFIDFClassifier
from attack.pipeline import AttackPipeline

# 智谱AI API Key
ZHIPU_API_KEY = "374a847ee1af4fe398fa3b1f681c1b8b.oppCxAznqjb0RIfs"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test-data', type=str,
                        default='data/test.pkl',
                        help='测试数据路径')
    parser.add_argument('--model', type=str,
                        default='models/tfidf_model.pkl',
                        help='模型路径')
    parser.add_argument('--output', type=str,
                        default='results/attack_results.pkl',
                        help='攻击结果输出路径')
    parser.add_argument('--max-samples', type=int, default=0,
                        help='最大测试样本数（0表示全部）')
    parser.add_argument('--use-llm', action='store_true',
                        help='是否使用智谱AI进行句级改写攻击')
    parser.add_argument('--use-targeted-dict', action='store_true',
                        help='使用针对测试集预构建的同义词子集')
    args = parser.parse_args()

    print("=" * 60)
    print("对抗攻击测试")
    print("=" * 60)

    # 加载模型
    print(f"\n加载模型: {args.model}")
    classifier = TFIDFClassifier()
    classifier.load(args.model)
    print("模型加载成功!")

    # 测试模型
    test_text = "您的银行卡异常，请提供验证码"
    pred = classifier.predict(test_text)
    print(f"测试预测: {pred} (1=诈骗, 0=正常)")

    # 加载测试数据
    print(f"\n加载测试数据: {args.test_data}")
    test_data = load_processed_data('test')
    if test_data is None:
        print("错误: 测试数据不存在")
        return

    # 限制样本数
    if args.max_samples > 0:
        test_data = test_data[:args.max_samples]

    fraud_count = sum(1 for d in test_data if d['class'] == 1)
    print(f"测试集: 总计={len(test_data)}, 诈骗={fraud_count}")

    # 加载同义词词典
    print("\n加载同义词词典...")
    if args.use_targeted_dict:
        synonym_dict = load_targeted_synonym_dict()
        if synonym_dict:
            print(f"使用预构建子集词典: {len(synonym_dict)} 个词条")
        else:
            print("预构建词典不存在，先运行 python build_targeted_dict.py")
            return
    else:
        synonym_dict = load_synonym_dict()
        print(f"使用完整词典: {len(synonym_dict)} 个词条")

    # 初始化智谱AI客户端
    llm_client = None
    if args.use_llm:
        try:
            from zhipuai import ZhipuAI
            llm_client = ZhipuAI(api_key=ZHIPU_API_KEY)
            print("智谱AI客户端初始化成功（句级改写攻击已启用）")
        except Exception as e:
            print(f"智谱AI初始化失败: {e}")
            print("将使用规则改写")

    # 初始化攻击管道
    pipeline = AttackPipeline(
        classifier=classifier,
        synonym_dict=synonym_dict,
        llm_client=llm_client
    )

    # 运行攻击
    results = pipeline.run_attack(test_data, args.output)

    # 显示示例
    print("\n攻击成功示例:")
    success_examples = [r for r in results if r['success']][:3]
    for i, r in enumerate(success_examples):
        print(f"\n示例 {i+1} ({r['method']}):")
        print(f"  原文: {r['orig_text'][:50]}...")
        print(f"  对抗: {r['adv_text'][:50]}...")
        print(f"  预测: {r['orig_pred']} -> {r['adv_pred']}")

    print("\n" + "=" * 60)
    print("攻击完成!")
    print("=" * 60)


if __name__ == '__main__':
    main()
