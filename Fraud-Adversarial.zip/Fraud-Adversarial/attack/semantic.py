"""
语义空间攻击 - 同义词替换
基于 SemAttack (NAACL 2022) 论文思想

目标：在不破坏语义的基础上替换关键诈骗词汇
"""
import jieba
from collections import Counter


class SemanticAttack:
    """语义空间攻击：同义词替换"""

    def __init__(self, classifier, synonym_dict, similarity_threshold=0.80):
        """
        初始化
        classifier: 分类器实例
        synonym_dict: 同义词词典 {词: [同义词列表]}
        similarity_threshold: 语义相似度阈值（默认0.80）
        """
        self.classifier = classifier
        self.synonym_dict = synonym_dict
        self.threshold = similarity_threshold

    def extract_keywords(self, text):
        """
        抽取关键词（使用TF-IDF/词典）
        返回在同义词词典中的关键词列表
        """
        # 使用jieba分词
        words = jieba.cut(text)
        words = [w for w in words if len(w) > 1]  # 过滤单字

        # 统计词频
        word_counts = Counter(words)

        # 返回在同义词词典中的词
        keywords = []
        for word, count in word_counts.most_common(20):
            if word in self.synonym_dict:
                keywords.append((word, count))

        return keywords

    def check_similarity(self, orig_text, new_text):
        """
        检查语义相似度
        简化版：基于长度变化比例
        """
        len_ratio = min(len(orig_text), len(new_text)) / max(len(orig_text), len(new_text), 1)
        return len_ratio

    def attack(self, text):
        """
        语义空间攻击：同义词替换（激进版）

        伪代码：
        1. 抽取所有在词典中的关键词
        2. 尝试所有可能的组合替换
        3. 语义相似度检查
        4. 检查是否骗过模型

        返回: (对抗文本或None, 使用的替换或None)
        """
        import random

        # 1. 获取原始预测
        orig_pred = self.classifier.predict(text)
        if orig_pred != 1:
            return None, None  # 非诈骗文本，不攻击

        # 2. 抽取所有在词典中的关键词
        words = jieba.cut(text)
        words = [w for w in words if len(w) > 1]
        keywords = [w for w in words if w in self.synonym_dict]
        keywords = list(set(keywords))  # 去重

        if not keywords:
            return None, None

        # 3. 尝试激进替换 - 一次性替换多个词
        # 策略1: 替换所有找到的词
        for _ in range(3):  # 尝试多次不同的替换组合
            new_text = text
            replaced_pairs = []

            for keyword in keywords:
                if keyword not in self.synonym_dict:
                    continue
                candidates = self.synonym_dict[keyword]
                # 过滤掉自己
                valid_candidates = [c for c in candidates if c != keyword]
                if not valid_candidates:
                    continue

                # 随机选择一个候选词
                candidate = random.choice(valid_candidates)
                new_text = new_text.replace(keyword, candidate)
                replaced_pairs.append(f"{keyword}->{candidate}")

            if new_text != text:
                sim = self.check_similarity(text, new_text)
                if sim >= self.threshold:
                    new_pred = self.classifier.predict(new_text)
                    if new_pred != orig_pred:
                        return new_text, ", ".join(replaced_pairs[:3])

        # 4. 策略2: 逐一尝试每个关键词的替换
        for keyword in keywords:
            if keyword not in self.synonym_dict:
                continue

            candidates = self.synonym_dict[keyword]
            for candidate in candidates:
                if candidate == keyword:
                    continue

                new_text = text.replace(keyword, candidate)
                if new_text == text:
                    continue

                sim = self.check_similarity(text, new_text)
                if sim < self.threshold:
                    continue

                new_pred = self.classifier.predict(new_text)
                if new_pred != orig_pred:
                    return new_text, f"{keyword}->{candidate}"

        return None, None
