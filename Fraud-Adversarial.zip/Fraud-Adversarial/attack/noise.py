"""
字符扰动攻击 - 规则扰动
基于 SemAttack (NAACL 2022) 论文思想

目标：中文特有攻击，让模型识别失败，但人类仍看懂

扰动规则：
- 插入空格: 验证码 -> 验 证 码
- 拼音混写: 银行 -> bank+银行
- 同音替换: 账号 -> 帐一号
- Unicode相似: 验 -> 騐
"""


class NoiseAttack:
    """字符扰动空间：规则扰动"""

    def __init__(self, classifier, similarity_threshold=0.80):
        """
        初始化
        classifier: 分类器实例
        similarity_threshold: 语义相似度阈值（默认0.80，字符扰动容忍度更高）
        """
        self.classifier = classifier
        self.threshold = similarity_threshold

        # 定义扰动规则
        self.rules = [
            # ============ 插入空格（核心诈骗词汇）============
            (r"验证码", r"验 证 码"),
            (r"身份证", r"身 份 证"),
            (r"银行卡", r"银 行 卡"),
            (r"账户", r"账 户"),
            (r"密码", r"密 码"),
            (r"链接", r"链 接"),
            (r"APP", r"A P P"),
            (r"下载", r"下 载"),
            (r"微信", r"微 信"),
            (r"贷款", r"贷 款"),
            (r"投资", r"投 资"),
            (r"退款", r"退 款"),
            (r"支付", r"支 付"),
            (r"手续费", r"手 续 费"),
            (r"银行", r"银 行"),
            (r"客服", r"客 服"),
            (r"申请", r"申 请"),
            (r"审核", r"审 核"),
            (r"放款", r"放 款"),
            (r"流水", r"流 水"),
            (r"信用", r"信 用"),
            (r"资料", r"资 料"),
            (r"操作", r"操 作"),
            (r"填写", r"填 写"),
            (r"完成", r"完 成"),
            (r"注册", r"注 册"),
            (r"核实", r"核 实"),
            (r"处理", r"处 理"),
            (r"确认", r"确 认"),
            (r"风险", r"风 险"),
            (r"收益", r"收 益"),
            (r"资金", r"资 金"),
            (r"安全", r"安 全"),
            (r"保障", r"保 障"),
            # ============ 拼音混写 ============
            (r"银行", r"bank"),
            (r"验证", r"yanzheng"),
            (r"密码", r"mima"),
            (r"账户", r"zhanghu"),
            (r"链接", r"link"),
            (r"微信", r"weixin"),
            (r"贷款", r"daikuan"),
            (r"APP", r"a-p-p"),
            (r"下载", r"xiazai"),
            (r"投资", r"touzi"),
            (r"客服", r"kefu"),
            (r"安全", r"anquan"),
            (r"审核", r"shenhe"),
            (r"注册", r"zhuce"),
            # ============ 同音替换 ============
            (r"账号", r"帐一号"),
            (r"验证", r"验 正"),
            (r"密码", r"密 码"),
            (r"支付", r"支-fu"),
            (r"银行", r"yin-hang"),
            (r"资金", r"zi-jin"),
            (r"安全", r"an-quan"),
            (r"收益", r"shou-yi"),
            # ============ Unicode形近字替换 ============
            (r"微", r"薇"),
            (r"信", r"伈"),
            (r"银", r"鍉"),
            (r"行", r"恦"),
            (r"支", r"吱"),
            (r"付", r"坿"),
            (r"验", r"騐"),
            (r"证", r"証"),
            (r"码", r"碼"),
            (r"账", r"帳"),
            (r"户", r"戶"),
            # ============ 数字替换 ============
            (r"一", r"1"),
            (r"二", r"2"),
            (r"三", r"3"),
            (r"四", r"4"),
            (r"五", r"5"),
            (r"六", r"6"),
            (r"七", r"7"),
            (r"八", r"8"),
            (r"九", r"9"),
            (r"十", r"10"),
            (r"零", r"0"),
            # ============ 混合扰动（各种符号插入）============
            (r"验证码", r"验证码 "),
            (r"链接", r"链.接"),
            (r"下载", r"下~载"),
            (r"银行", r"yin行"),
            (r"贷款", r"贷.款"),
            (r"投资", r"投*资"),
            (r"微信", r"微#信"),
            (r"安全", r"安+全"),
            (r"账户", r"账=户"),
            (r"客服", r"客^服"),
            (r"申请", r"申@请"),
            (r"审核", r"审#核"),
            (r"支付", r"支/付"),
            (r"资金", r"资&金"),
            (r"注册", r"注%册"),
            # ============ 添加无关字符 ============
            (r"好的", r"好的呢"),
            (r"是的", r"是的呀"),
            (r"收到", r"收到啦"),
            (r"谢谢", r"谢谢啦"),
            (r"请问", r"请问哦"),
            (r"可以", r"可以呀"),
            (r"马上", r"马上哦"),
            (r"尽快", r"尽快呢"),
            # ============ 关键词拆分 ============
            (r"下载", r"下 + 载"),
            (r"注册", r"注 + 册"),
            (r"审核", r"审 + 核"),
            (r"确认", r"确 + 认"),
            (r"填写", r"填 + 写"),
            # ============ 英文替代 ============
            (r"贷款", r"loan"),
            (r"投资", r"invest"),
            (r"银行", r"bank"),
            (r"安全", r"safe"),
            (r"收益", r"profit"),
            (r"资金", r"capital"),
            (r"审核", r"review"),
            (r"链接", r"URL"),
            (r"官网", r"website"),
        ]

    def apply_rule(self, text, pattern, replacement):
        """应用单条规则"""
        import re
        return re.sub(pattern, replacement, text)

    def check_similarity(self, orig_text, new_text):
        """检查语义相似度"""
        len_ratio = min(len(orig_text), len(new_text)) / max(len(orig_text), len(new_text), 1)
        return len_ratio

    def attack(self, text):
        """字符扰动攻击"""
        orig_pred = self.classifier.predict(text)
        if orig_pred != 1:
            return None, None

        for i, (pattern, replacement) in enumerate(self.rules):
            new_text = self.apply_rule(text, pattern, replacement)
            if new_text == text:
                continue

            sim = self.check_similarity(text, new_text)
            if sim < self.threshold:
                continue

            new_pred = self.classifier.predict(new_text)
            if new_pred != orig_pred:
                return new_text, f"noise-{i+1}"

        return None, None
