"""
攻击协调器 - Attack Pipeline
基于 SemAttack (NAACL 2022) 论文思想

协调三层攻击策略：语义空间 -> 句级改写 -> 字符扰动
"""
import os
import joblib
from tqdm import tqdm
from attack.semantic import SemanticAttack
from attack.paraphrase import ParaphraseAttack
from attack.noise import NoiseAttack


class AttackPipeline:
    """攻击协调器：逐层尝试三种攻击空间"""

    def __init__(self, classifier, synonym_dict, llm_client=None):
        """
        初始化
        classifier: 分类器实例
        synonym_dict: 同义词词典（用于语义攻击）
        llm_client: LLM客户端（用于句级改写攻击）
        """
        self.classifier = classifier

        # 初始化三种攻击（使用优化后的阈值）
        self.semantic_attack = SemanticAttack(
            classifier, synonym_dict, similarity_threshold=0.80
        )
        self.paraphrase_attack = ParaphraseAttack(
            classifier, llm_client, similarity_threshold=0.75
        )
        self.noise_attack = NoiseAttack(classifier, similarity_threshold=0.80)

    def attack(self, text, label):
        """
        对单条文本进行攻击

        伪代码：
        1. 只攻击诈骗样本
        2. 获取原始预测
        3. 逐层尝试攻击

        返回: {
            'orig_text': str,
            'adv_text': str or None,
            'method': str,
            'success': bool,
            'orig_pred': int,
            'adv_pred': int or None
        }
        """
        result = {
            'orig_text': text,
            'adv_text': None,
            'method': 'skipped',
            'success': False,
            'orig_pred': self.classifier.predict(text),
            'adv_pred': None
        }

        # 1. 只攻击诈骗样本
        if label != 1:
            result['method'] = 'skipped'
            return result

        # 2. 模型已正确识别为非诈骗，不攻击
        if result['orig_pred'] != 1:
            result['method'] = 'skipped'
            return result

        # 3. 逐层尝试攻击

        # --- 攻击1：语义空间 ---
        adv_text, candidate = self.semantic_attack.attack(text)
        if adv_text:
            result['adv_text'] = adv_text
            result['adv_pred'] = self.classifier.predict(adv_text)
            result['method'] = f'semantic ({candidate})'
            result['success'] = True
            return result

        # --- 攻击2：句级改写 ---
        adv_text, method = self.paraphrase_attack.attack(text)
        if adv_text:
            result['adv_text'] = adv_text
            result['adv_pred'] = self.classifier.predict(adv_text)
            result['method'] = f'paraphrase ({method})'
            result['success'] = True
            return result

        # --- 攻击3：字符扰动 ---
        adv_text, rule = self.noise_attack.attack(text)
        if adv_text:
            result['adv_text'] = adv_text
            result['adv_pred'] = self.classifier.predict(adv_text)
            result['method'] = f'noise ({rule})'
            result['success'] = True
            return result

        # 4. 所有攻击都失败
        result['method'] = 'failed'
        return result

    def run_attack(self, test_data, output_path=None):
        """
        对测试数据进行攻击

        返回: 结果列表
        """
        results = []

        print("开始对抗攻击...")
        for item in tqdm(test_data):
            text = item['text']
            label = item['class']

            # 只攻击诈骗样本
            if label != 1:
                continue

            result = self.attack(text, label)
            results.append(result)

        # 统计结果
        total = len(results)
        success = sum(1 for r in results if r['success'])
        failed = sum(1 for r in results if r['method'] == 'failed')
        skipped = sum(1 for r in results if r['method'] == 'skipped')

        print("\n" + "=" * 60)
        print("攻击结果统计")
        print("=" * 60)
        print(f"总攻击样本数: {total}")
        print(f"成功: {success} ({success/total*100:.1f}%)")
        print(f"失败: {failed} ({failed/total*100:.1f}%)")
        print(f"跳过: {skipped}")

        # 按方法统计
        method_stats = {}
        for r in results:
            if r['method'] not in ['failed', 'skipped']:
                method = r['method'].split(' ')[0]
                method_stats[method] = method_stats.get(method, 0) + 1

        print("\n按攻击方法统计:")
        for method, count in method_stats.items():
            print(f"  {method}: {count}")

        # 保存结果
        if output_path:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            joblib.dump(results, output_path)
            print(f"\n结果保存到: {output_path}")

        return results
