"""
攻击模块初始化
"""
from attack.semantic import SemanticAttack
from attack.paraphrase import ParaphraseAttack
from attack.noise import NoiseAttack
from attack.pipeline import AttackPipeline

__all__ = ['SemanticAttack', 'ParaphraseAttack', 'NoiseAttack', 'AttackPipeline']
