"""
句级改写攻击 - LLM改写
基于 SemAttack (NAACL 2022) 论文思想

目标：生成"更加自然、更加委婉、更加绕"的诈骗表达
"""
import re
import time


class ParaphraseAttack:
    """句级改写空间：LLM改写"""

    def __init__(self, classifier, llm_client=None, similarity_threshold=0.75,
                 llm_rewrite_interval=5, max_retries=3):
        """
        初始化
        classifier: 分类器实例
        llm_client: LLM客户端（如智谱AI），None则使用规则改写
        similarity_threshold: 语义相似度阈值（默认0.75）
        llm_rewrite_interval: LLM改写频率，每N次攻击使用1次LLM（默认5）
        max_retries: API调用最大重试次数（默认3）
        """
        self.classifier = classifier
        self.llm_client = llm_client
        self.threshold = similarity_threshold
        self.attack_count = 0
        self.llm_rewrite_interval = llm_rewrite_interval  # 方案A: 降低频率
        self.max_retries = max_retries  # 方案C: 重试次数

    def paraphrase_with_llm(self, text):
        """使用LLM进行改写（带重试和退避）"""
        if self.llm_client is None:
            return None

        # 构建Prompt - 更明确地指导LLM
        prompt = f"""你是一位专业的文案改写专家。请将下面的对话进行改写，要求：

【核心任务】
这是一条诈骗对话，你需要将其改写成"不像诈骗"的版本，同时保持原意不变。

【改写要求】
1. **消除诈骗特征**：去除"马上"、"立即"、"必须"、"验证码"、"银行卡"等明显诈骗词汇
2. **使用委婉表达**：将命令式语气改为建议式、询问式
3. **伪装正常服务**：让它听起来像是正常的银行/客服服务
4. **保持核心意图**：收钱、提供信息、下载APP等目的不能变

【改写技巧】
- 把"你必须"改成"建议您"
- 把"立即转账"改成"方便时操作"
- 把"验证码"改成"确认码"或"安全码"
- 把"银行卡"改成"账户"或"卡号"
- 加入"请问"、"方便的话"等礼貌用语

原文：{text}

请直接输出改写后的内容，不要解释："""

        # 方案C: 带重试的API调用
        for retry in range(self.max_retries):
            try:
                response = self.llm_client.chat.completions.create(
                    model="glm-4.5-flash",
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=512,
                    temperature=0.7
                )
                new_text = response.choices[0].message.content.strip()
                return new_text
            except Exception as e:
                error_str = str(e)
                # 429错误：指数退避
                if "429" in error_str or "请求过多" in error_str:
                    wait_time = (2 ** retry) * 2  # 2, 4, 8秒退避
                    print(f"  API限流，等待{wait_time}秒后重试({retry+1}/{self.max_retries})...")
                    time.sleep(wait_time)
                    continue
                else:
                    print(f"LLM调用失败: {e}")
                    return None
        print("LLM重试次数耗尽，跳过本次改写")
        return None

    def paraphrase_with_rules(self, text):
        """使用规则进行改写（无需LLM）"""
        rules = [
            # ============ 委婉化 ============
            (r"请立即", "请您尽快"),
            (r"马上", "尽快"),
            (r"立刻", "尽快"),
            (r"赶紧", "请尽快"),
            (r"必须", "需要"),
            (r"立即", "尽快"),
            (r"快点", "尽快"),
            (r"尽快", "尽快哦"),
            (r"马上", "马上好"),
            (r"立即", "马上呢"),
            (r"赶紧", "抓紧哦"),
            # ============ 人称改写 ============
            (r"你", "您"),
            (r"你", "这位朋友"),
            (r"你", "这位"),
            (r"需要你", "需要您"),
            (r"你提供", "您提供"),
            (r"你填写", "您填写"),
            (r"你下载", "您下载"),
            (r"你注册", "您注册"),
            # ============ 请求改写 ============
            (r"提供", "协助确认"),
            (r"告诉我们", "帮忙核对"),
            (r"告诉我", "帮忙核对"),
            (r"说出", "说出（避免敏感词）"),
            (r"提供", "协助提供"),
            (r"提供信息", "确认相关信息"),
            # ============ 解释改写 ============
            (r"你的账户异常", "您的账户出现了一些状况"),
            (r"银行卡异常", "卡片出现了一些状况"),
            (r"身份验证", "核实身份信息"),
            (r"验证码", "确认码"),
            (r"账户安全", "账户方面的问题"),
            (r"点击链接", "点一下这个"),
            (r"下载APP", "下载应用程序"),
            (r"官方APP", "官方应用程序"),
            (r"客服电话", "客服联系方式"),
            (r"微信", "微 信"),
            (r"下载", "获取"),
            (r"点击", "轻点"),
            (r"链接", "这个地址"),
            # ============ 添加语气词 ============
            (r"好的", "好的呢"),
            (r"是的", "是的呀"),
            (r"收到", "收到啦"),
            (r"谢谢", "谢谢啦"),
            (r"请问", "请问哦"),
            (r"可以", "可以呀"),
            (r"明白", "明白啦"),
            # ============ 无关字符扰动 ============
            (r"贷款", "贷~款"),
            (r"投资", "投~资"),
            (r"银行", "银~行"),
            (r"链接", "链~接"),
            (r"验证", "验*证"),
            (r"支付", "支/付"),
            (r"安全", "安+全"),
            (r"资金", "资&金"),
            (r"收益", "收*益"),
            (r"客服", "客^服"),
            # ============ 关键词拆分 ============
            (r"下载", "下 载"),
            (r"注册", "注 册"),
            (r"审核", "审 核"),
            (r"确认", "确 认"),
            (r"填写", "填 写"),
            (r"操作", "操 作"),
            # ============ 英文替代 ============
            (r"APP", "A-P-P"),
            (r"银行", "bank"),
            (r"贷款", "loan"),
            (r"投资", "invest"),
            (r"安全", "safe"),
            # ============ 添加无关词汇 ============
            (r"贷款", "贷款产品"),
            (r"投资", "投资项目"),
            (r"银行", "银行方面"),
            (r"客服", "客服专员"),
            (r"审核", "审核流程"),
            (r"申请", "申请流程"),
            (r"放款", "放款方式"),
        ]

        new_text = text
        for pattern, replacement in rules:
            new_text = re.sub(pattern, replacement, new_text)

        return new_text if new_text != text else None

    def check_similarity(self, orig_text, new_text):
        """
        检查语义相似度
        简化版：基于长度变化比例
        """
        len_ratio = min(len(orig_text), len(new_text)) / max(len(orig_text), len(new_text), 1)
        return len_ratio

    def attack(self, text):
        """
        句级改写攻击

        伪代码：
        1. 构建Prompt
        2. 调用LLM（频率控制）
        3. 语义相似度检查
        4. 检查是否骗过模型

        返回: (对抗文本或None, 使用的改写方式)
        """
        # 1. 获取原始预测
        orig_pred = self.classifier.predict(text)
        if orig_pred != 1:
            return None, None

        # 2. 方案A: 降低LLM改写频率
        self.attack_count += 1
        use_llm = (self.llm_client is not None and
                   self.attack_count % self.llm_rewrite_interval == 0)

        if use_llm:
            new_text = self.paraphrase_with_llm(text)
            if new_text:
                sim = self.check_similarity(text, new_text)
                if sim >= self.threshold:
                    new_pred = self.classifier.predict(new_text)
                    if new_pred != orig_pred:
                        return new_text, "llm"

        # 3. 尝试规则改写
        new_text = self.paraphrase_with_rules(text)
        if new_text:
            sim = self.check_similarity(text, new_text)
            if sim >= self.threshold:
                new_pred = self.classifier.predict(new_text)
                if new_pred != orig_pred:
                    return new_text, "rule"

        return None, None
