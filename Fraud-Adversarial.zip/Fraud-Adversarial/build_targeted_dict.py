"""
预构建同义词词林
针对测试集文本预先提取相关同义词，加速攻击
"""
import os
import jieba
import joblib
from collections import Counter
from data import load_full_synonym_dict


def extract_test_keywords(test_data, top_n=2000):
    """
    从测试集提取高频词
    """
    all_words = []
    for item in test_data:
        words = jieba.cut(item['text'])
        words = [w for w in words if len(w) >= 2]
        all_words.extend(words)

    word_counts = Counter(all_words)
    return word_counts.most_common(top_n)


def build_targeted_synonym_dict(test_data, full_dict, top_keywords=2000):
    """
    构建针对测试集的同义词子集

    步骤：
    1. 提取测试集高频词
    2. 只保留这些词在同义词词典中的条目
    3. 保存为紧凑格式
    """
    print("=" * 60)
    print("预构建同义词词林")
    print("=" * 60)

    # 1. 提取测试集高频词
    print(f"\n[1] 分析测试集词汇...")
    test_keywords = extract_test_keywords(test_data, top_n=top_keywords)
    print(f"   测试集高频词: {len(test_keywords)} 个")

    # 2. 构建子集词典
    print(f"\n[2] 构建同义词子集...")
    targeted_dict = {}
    matched_count = 0

    for word, freq in test_keywords:
        if word in full_dict:
            synonyms = full_dict[word]
            targeted_dict[word] = synonyms
            matched_count += 1

    print(f"   匹配到同义词的词: {matched_count} 个")
    print(f"   子集词典大小: {len(targeted_dict)} 个词条")

    # 3. 统计同义词数量
    total_synonyms = sum(len(v) for v in targeted_dict.values())
    avg_synonyms = total_synonyms / len(targeted_dict) if targeted_dict else 0
    print(f"   同义词总数: {total_synonyms} 个")
    print(f"   平均同义词数: {avg_synonyms:.1f} 个/词")

    # 4. 显示示例
    print(f"\n[3] 示例（前10个）:")
    for i, (word, synonyms) in enumerate(list(targeted_dict.items())[:10]):
        print(f"   {word}: {synonyms[:5]}{'...' if len(synonyms) > 5 else ''}")

    # 5. 保存
    output_path = 'data/targeted_synonym_dict.pkl'
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    joblib.dump(targeted_dict, output_path)
    print(f"\n[4] 保存到: {output_path}")

    print("\n" + "=" * 60)
    print("预构建完成!")
    print("=" * 60)

    return targeted_dict


def load_targeted_synonym_dict(path='data/targeted_synonym_dict.pkl'):
    """加载预构建的同义词子集"""
    if os.path.exists(path):
        return joblib.load(path)
    return None


if __name__ == '__main__':
    from data import load_processed_data

    # 加载清洗后的测试数据
    test_data = load_processed_data('test_clean')
    if test_data is None:
        test_data = load_processed_data('test')

    if test_data:
        # 加载完整同义词词典
        full_dict = load_full_synonym_dict()
        print(f"完整词典: {len(full_dict)} 词条")

        # 构建子集词典
        targeted_dict = build_targeted_synonym_dict(test_data, full_dict, top_keywords=2000)
