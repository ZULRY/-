"""
攻击结果导出工具
将对抗样本导出为易读的格式（CSV, TXT, Markdown）
"""
import os
import csv
import joblib


def export_to_csv(results, output_path, include_failed=False):
    """
    导出到CSV文件

    Args:
        results: 攻击结果列表
        output_path: 输出文件路径
        include_failed: 是否包含失败的样本
    """
    # 过滤数据
    filtered_results = results
    if not include_failed:
        filtered_results = [r for r in results if r['success']]

    if not filtered_results:
        print("警告: 没有可导出的成功样本")
        return

    fieldnames = ['orig_text', 'adv_text', 'method', 'orig_pred', 'adv_pred']

    with open(output_path, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for r in filtered_results:
            # 截断过长的文本
            row = {
                'orig_text': r['orig_text'][:500] if r['orig_text'] else '',
                'adv_text': r['adv_text'][:500] if r['adv_text'] else '',
                'method': r['method'],
                'orig_pred': r['orig_pred'],
                'adv_pred': r['adv_pred']
            }
            writer.writerow(row)

    print(f"CSV导出完成: {output_path} ({len(filtered_results)} 条)")


def export_to_markdown(results, output_path, include_failed=False, max_examples=50):
    """
    导出到Markdown文件（格式化的对比表格）

    Args:
        results: 攻击结果列表
        output_path: 输出文件路径
        include_failed: 是否包含失败的样本
        max_examples: 最大导出数量
    """
    filtered_results = results
    if not include_failed:
        filtered_results = [r for r in results if r['success']]

    if not filtered_results:
        print("警告: 没有可导出的成功样本")
        return

    # 限制数量
    filtered_results = filtered_results[:max_examples]

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("# 对抗攻击成功样本\n\n")

        f.write("## 统计信息\n\n")
        total = len(results)
        success = sum(1 for r in results if r['success'])
        f.write(f"- 总攻击样本: {total}\n")
        f.write(f"- 成功攻击: {success} ({success/total*100:.2f}%)\n")
        f.write(f"- 本次导出: {len(filtered_results)} 条\n\n")

        f.write("## 攻击方法统计\n\n")
        method_stats = {}
        for r in results:
            if r['success'] and r['method']:
                method = r['method'].split(' ')[0]
                method_stats[method] = method_stats.get(method, 0) + 1
        for method, count in sorted(method_stats.items(), key=lambda x: -x[1]):
            f.write(f"- {method}: {count} 条\n")
        f.write("\n")

        f.write("## 成功样本对比\n\n")
        f.write("| 序号 | 原始文本 | 对抗文本 | 方法 | 预测变化 |\n")
        f.write("|------|----------|----------|------|----------|\n")

        for i, r in enumerate(filtered_results, 1):
            orig = r['orig_text'][:30] + '...' if len(r['orig_text']) > 30 else r['orig_text']
            adv = r['adv_text'][:30] + '...' if len(r['adv_text']) > 30 else r['adv_text']
            method = r['method'].split(' ')[0] if r['method'] else '-'
            pred_change = f"{r['orig_pred']}→{r['adv_pred']}"

            # 转义markdown表格中的竖线
            orig = orig.replace('|', '\\|')
            adv = adv.replace('|', '\\|')

            f.write(f"| {i} | {orig} | {adv} | {method} | {pred_change} |\n")

        f.write("\n## 详细样本\n\n")

        for i, r in enumerate(filtered_results, 1):
            f.write(f"### 样本 {i} ({r['method']})\n\n")
            f.write("**原始文本:**\n")
            f.write(f"> {r['orig_text']}\n\n")
            f.write("**对抗文本:**\n")
            f.write(f"> {r['adv_text']}\n\n")
            f.write(f"- 原始预测: `{r['orig_pred']}` → 对抗预测: `{r['adv_pred']}`\n\n")
            f.write("---\n\n")

    print(f"Markdown导出完成: {output_path} ({len(filtered_results)} 条)")


def export_to_txt(results, output_path, include_failed=False):
    """
    导出到纯文本文件（简单格式）

    Args:
        results: 攻击结果列表
        output_path: 输出文件路径
        include_failed: 是否包含失败的样本
    """
    filtered_results = results
    if not include_failed:
        filtered_results = [r for r in results if r['success']]

    if not filtered_results:
        print("警告: 没有可导出的成功样本")
        return

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("=" * 70 + "\n")
        f.write("对抗攻击成功样本列表\n")
        f.write("=" * 70 + "\n\n")

        for i, r in enumerate(filtered_results, 1):
            f.write(f"【{i}】{r['method']}\n")
            f.write(f"  原始: {r['orig_text']}\n")
            f.write(f"  对抗: {r['adv_text']}\n")
            f.write(f"  预测: {r['orig_pred']} → {r['adv_pred']}\n")
            f.write("-" * 70 + "\n")

    print(f"TXT导出完成: {output_path} ({len(filtered_results)} 条)")


def export_attack_comparison(results_path, output_dir='results/export'):
    """
    一键导出多种格式

    Args:
        results_path: 攻击结果文件路径
        output_dir: 输出目录
    """
    os.makedirs(output_dir, exist_ok=True)

    # 加载结果
    results = joblib.load(results_path)
    if results is None:
        print(f"错误: 无法加载结果文件 {results_path}")
        return

    # 统计
    total = len(results)
    success = sum(1 for r in results if r['success'])
    failed = sum(1 for r in results if r['method'] == 'failed')

    print(f"\n{'='*60}")
    print("攻击结果导出")
    print(f"{'='*60}")
    print(f"总样本: {total}")
    print(f"成功: {success} ({success/total*100:.2f}%)")
    print(f"失败: {failed} ({failed/total*100:.2f}%)")
    print()

    # 导出CSV
    export_to_csv(results, f"{output_dir}/attack_success_samples.csv")

    # 导出Markdown
    export_to_markdown(results, f"{output_dir}/attack_success_report.md")

    # 导出TXT
    export_to_txt(results, f"{output_dir}/attack_success_list.txt")

    # 导出统计信息
    with open(f"{output_dir}/attack_statistics.txt", 'w', encoding='utf-8') as f:
        f.write("攻击结果统计\n")
        f.write("=" * 50 + "\n\n")
        f.write(f"总攻击样本数: {total}\n")
        f.write(f"成功攻击数: {success}\n")
        f.write(f"失败攻击数: {failed}\n")
        f.write(f"攻击成功率 (ASR): {success/total*100:.2f}%\n\n")

        # 按方法统计
        f.write("按攻击方法统计:\n")
        method_stats = {}
        for r in results:
            if r['success'] and r['method']:
                method = r['method'].split(' ')[0]
                method_stats[method] = method_stats.get(method, 0) + 1
        for method, count in sorted(method_stats.items(), key=lambda x: -x[1]):
            f.write(f"  {method}: {count} ({count/success*100:.1f}%)\n")

    print(f"\n统计信息已保存: {output_dir}/attack_statistics.txt")
    print(f"\n所有导出文件保存在: {output_dir}")


def export_failed_samples(results, output_path):
    """
    导出失败样本（用于分析改进方向）

    Args:
        results: 攻击结果列表
        output_path: 输出文件路径
    """
    failed_results = [r for r in results if r['method'] == 'failed']

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("对抗攻击失败样本分析\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"失败样本数: {len(failed_results)}\n\n")

        for i, r in enumerate(failed_results, 1):
            f.write(f"【{i}】\n")
            f.write(f"  文本: {r['orig_text'][:100]}...\n")
            f.write(f"  原始预测: {r['orig_pred']}\n")
            f.write("-" * 40 + "\n")

    print(f"失败样本已导出: {output_path} ({len(failed_results)} 条)")


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', type=str, default='results/attack_results.pkl',
                        help='攻击结果文件路径')
    parser.add_argument('--output-dir', type=str, default='results/export',
                        help='输出目录')
    parser.add_argument('--format', type=str, default='all',
                        choices=['csv', 'md', 'txt', 'all'],
                        help='导出格式')
    parser.add_argument('--include-failed', action='store_true',
                        help='是否包含失败样本')
    args = parser.parse_args()

    print("=" * 60)
    print("攻击结果导出工具")
    print("=" * 60)

    # 加载结果
    if not os.path.exists(args.results):
        print(f"错误: 结果文件不存在 {args.results}")
        return

    results = joblib.load(args.results)

    if args.format == 'all':
        export_attack_comparison(args.results, args.output_dir)
    elif args.format == 'csv':
        export_to_csv(results, f"{args.output_dir}/attack_results.csv", args.include_failed)
    elif args.format == 'md':
        export_to_markdown(results, f"{args.output_dir}/attack_report.md", args.include_failed)
    elif args.format == 'txt':
        export_to_txt(results, f"{args.output_dir}/attack_list.txt", args.include_failed)

    # 导出失败样本分析
    if args.include_failed:
        export_failed_samples(results, f"{args.output_dir}/failed_samples.txt")


if __name__ == '__main__':
    main()
