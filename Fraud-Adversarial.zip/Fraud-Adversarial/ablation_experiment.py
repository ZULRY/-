"""
消融实验 - Ablation Study
测试不同攻击方法的独立效果和组合效果
"""
import os
import argparse
import joblib
from tqdm import tqdm
from data import load_processed_data, load_synonym_dict, load_targeted_synonym_dict
from models.tfidf_classifier import TFIDFClassifier
from attack.semantic import SemanticAttack
from attack.paraphrase import ParaphraseAttack
from attack.noise import NoiseAttack


def run_single_attack(test_data, attack_method, classifier, synonym_dict,
                      llm_client=None, use_targeted_dict=False):
    """
    运行单一攻击方法

    attack_method: 'semantic' | 'paraphrase' | 'noise'
    """
    results = []

    if attack_method == 'semantic':
        attack = SemanticAttack(classifier, synonym_dict, similarity_threshold=0.90)
    elif attack_method == 'paraphrase':
        attack = ParaphraseAttack(classifier, llm_client, similarity_threshold=0.85)
    elif attack_method == 'noise':
        attack = NoiseAttack(classifier, similarity_threshold=0.95)
    else:
        raise ValueError(f"Unknown attack method: {attack_method}")

    for item in tqdm(test_data, desc=f"{attack_method} attack"):
        text = item['text']
        label = item['class']

        # 只攻击诈骗样本
        if label != 1:
            continue

        orig_pred = classifier.predict(text)
        if orig_pred != 1:
            continue

        adv_text, method_info = attack.attack(text)

        result = {
            'orig_text': text,
            'adv_text': adv_text,
            'method': method_info,
            'success': adv_text is not None,
            'orig_pred': orig_pred,
            'adv_pred': classifier.predict(adv_text) if adv_text else None
        }
        results.append(result)

    return results


def run_ablation_experiment(test_data, classifier, synonym_dict, llm_client=None,
                            output_dir='results/ablation'):
    """
    运行完整的消融实验

    比较:
    1. 仅语义攻击 (semantic only)
    2. 仅句级改写 (paraphrase only)
    3. 仅字符扰动 (noise only)
    4. 组合攻击 (all combined) - 使用pipeline
    """
    os.makedirs(output_dir, exist_ok=True)

    results_summary = {}

    # 1. 仅语义攻击
    print("\n" + "=" * 60)
    print("实验1: 仅语义攻击 (Semantic Only)")
    print("=" * 60)
    semantic_results = run_single_attack(test_data, 'semantic', classifier, synonym_dict, llm_client)
    semantic_success = sum(1 for r in semantic_results if r['success'])
    semantic_total = len(semantic_results)
    results_summary['semantic'] = {
        'success': semantic_success,
        'total': semantic_total,
        'asr': semantic_success / semantic_total * 100 if semantic_total > 0 else 0
    }
    print(f"成功: {semantic_success}/{semantic_total} = {results_summary['semantic']['asr']:.2f}%")
    joblib.dump(semantic_results, f"{output_dir}/semantic_results.pkl")

    # 2. 仅句级改写
    print("\n" + "=" * 60)
    print("实验2: 仅句级改写 (Paraphrase Only)")
    print("=" * 60)
    paraphrase_results = run_single_attack(test_data, 'paraphrase', classifier, synonym_dict, llm_client)
    paraphrase_success = sum(1 for r in paraphrase_results if r['success'])
    paraphrase_total = len(paraphrase_results)
    results_summary['paraphrase'] = {
        'success': paraphrase_success,
        'total': paraphrase_total,
        'asr': paraphrase_success / paraphrase_total * 100 if paraphrase_total > 0 else 0
    }
    print(f"成功: {paraphrase_success}/{paraphrase_total} = {results_summary['paraphrase']['asr']:.2f}%")
    joblib.dump(paraphrase_results, f"{output_dir}/paraphrase_results.pkl")

    # 3. 仅字符扰动
    print("\n" + "=" * 60)
    print("实验3: 仅字符扰动 (Noise Only)")
    print("=" * 60)
    noise_results = run_single_attack(test_data, 'noise', classifier, synonym_dict, llm_client)
    noise_success = sum(1 for r in noise_results if r['success'])
    noise_total = len(noise_results)
    results_summary['noise'] = {
        'success': noise_success,
        'total': noise_total,
        'asr': noise_success / noise_total * 100 if noise_total > 0 else 0
    }
    print(f"成功: {noise_success}/{noise_total} = {results_summary['noise']['asr']:.2f}%")
    joblib.dump(noise_results, f"{output_dir}/noise_results.pkl")

    # 4. 组合攻击（使用Pipeline）
    print("\n" + "=" * 60)
    print("实验4: 组合攻击 (All Combined)")
    print("=" * 60)
    from attack.pipeline import AttackPipeline
    pipeline = AttackPipeline(classifier, synonym_dict, llm_client)
    combined_results = pipeline.run_attack(test_data, f"{output_dir}/combined_results.pkl")
    combined_success = sum(1 for r in combined_results if r['success'])
    combined_total = len(combined_results)
    results_summary['combined'] = {
        'success': combined_success,
        'total': combined_total,
        'asr': combined_success / combined_total * 100 if combined_total > 0 else 0
    }
    print(f"成功: {combined_success}/{combined_total} = {results_summary['combined']['asr']:.2f}%")

    # 保存汇总
    joblib.dump(results_summary, f"{output_dir}/ablation_summary.pkl")

    # 打印对比表
    print("\n" + "=" * 60)
    print("消融实验结果汇总")
    print("=" * 60)
    print(f"{'攻击方法':<20} {'成功':<10} {'总数':<10} {'ASR':<10}")
    print("-" * 50)
    for method, stats in results_summary.items():
        print(f"{method:<20} {stats['success']:<10} {stats['total']:<10} {stats['asr']:.2f}%")
    print("-" * 50)

    # 计算提升
    if 'semantic' in results_summary:
        base_asr = results_summary['semantic']['asr']
        combined_asr = results_summary['combined']['asr']
        improvement = combined_asr - base_asr
        print(f"\n组合攻击相比纯语义攻击提升: +{improvement:.2f}%")

    return results_summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test-data', type=str, default='data/test_clean.pkl')
    parser.add_argument('--model', type=str, default='models/tfidf_model.pkl')
    parser.add_argument('--output-dir', type=str, default='results/ablation')
    parser.add_argument('--max-samples', type=int, default=0)
    parser.add_argument('--use-llm', action='store_true')
    parser.add_argument('--use-targeted-dict', action='store_true')
    args = parser.parse_args()

    print("=" * 60)
    print("消融实验 - Ablation Study")
    print("=" * 60)

    # 加载模型
    print("\n加载模型...")
    classifier = TFIDFClassifier()
    classifier.load(args.model)

    # 加载测试数据
    print("加载测试数据...")
    test_data = load_processed_data('test')
    if test_data is None:
        test_data = load_processed_data('test_clean')
    if test_data is None:
        print("错误: 测试数据不存在")
        return

    if args.max_samples > 0:
        test_data = test_data[:args.max_samples]

    fraud_count = sum(1 for d in test_data if d['class'] == 1)
    print(f"测试集: 总计={len(test_data)}, 诈骗={fraud_count}")

    # 加载词典
    print("加载词典...")
    if args.use_targeted_dict:
        from data import load_targeted_synonym_dict
        synonym_dict = load_targeted_synonym_dict()
        if synonym_dict:
            print(f"使用预构建子集词典: {len(synonym_dict)} 个词条")
        else:
            print("预构建词典不存在")
            return
    else:
        from data import load_synonym_dict
        synonym_dict = load_synonym_dict()
        print(f"使用完整词典: {len(synonym_dict)} 个词条")

    # 初始化LLM
    llm_client = None
    if args.use_llm:
        try:
            from zhipuai import ZhipuAI
            ZHIPU_API_KEY = "374a847ee1af4fe398fa3b1f681c1b8b.oppCxAznqjb0RIfs"
            llm_client = ZhipuAI(api_key=ZHIPU_API_KEY)
            print("智谱AI客户端初始化成功")
        except Exception as e:
            print(f"智谱AI初始化失败: {e}")

    # 运行消融实验
    results = run_ablation_experiment(test_data, classifier, synonym_dict,
                                      llm_client, args.output_dir)

    print("\n消融实验完成!")
    print(f"结果保存在: {args.output_dir}")


if __name__ == '__main__':
    main()
