"""
模型训练入口
"""
import os
import argparse
import random
import numpy as np
import torch
import joblib

from data import save_processed_data, load_synonym_dict
from models.tfidf_classifier import TFIDFClassifier

def set_seed(seed=42):
    """设置随机种子"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--train-data', type=str, required=True,
                        help='训练数据pkl路径')
    parser.add_argument('--test-data', type=str,
                        help='测试数据pkl路径')
    parser.add_argument('--model-output', type=str,
                        default='models/tfidf_model.pkl',
                        help='模型输出路径')
    parser.add_argument('--seed', type=int, default=42,
                        help='随机种子')
    args = parser.parse_args()

    print("=" * 60)
    print("TF-IDF + SVM 分类器训练")
    print("=" * 60)

    # 设置随机种子
    set_seed(args.seed)

    # 加载数据
    print(f"\n加载训练数据: {args.train_data}")
    train_data = joblib.load(args.train_data)

    # 统计
    fraud_count = sum(1 for d in train_data if d['class'] == 1)
    normal_count = len(train_data) - fraud_count
    print(f"训练集: 总计={len(train_data)}, 诈骗={fraud_count}, 正常={normal_count}")

    # 加载测试数据（如果有）
    test_data = None
    if args.test_data:
        print(f"\n加载测试数据: {args.test_data}")
        test_data = joblib.load(args.test_data)
        fraud_count = sum(1 for d in test_data if d['class'] == 1)
        normal_count = len(test_data) - fraud_count
        print(f"测试集: 总计={len(test_data)}, 诈骗={fraud_count}, 正常={normal_count}")

    # 保存处理后的数据
    print("\n保存处理后的数据...")
    save_processed_data(train_data, 'train')
    if test_data:
        save_processed_data(test_data, 'test')

    # 训练模型
    classifier = TFIDFClassifier()
    classifier.train(train_data, test_data)

    # 在测试集上评估
    if test_data:
        test_texts = [item['text'] for item in test_data]
        test_labels = [item['class'] for item in test_data]
        test_acc = classifier.model.score(test_texts, test_labels)
        print(f"\n测试集准确率: {test_acc:.4f}")

        # 详细统计
        preds = classifier.model.predict(test_texts)
        fraud_acc = sum(1 for p, l in zip(preds, test_labels) if p == 1 and l == 1) / max(fraud_count, 1)
        normal_acc = sum(1 for p, l in zip(preds, test_labels) if p == 0 and l == 0) / max(normal_count, 1)
        print(f"  诈骗类准确率: {fraud_acc:.4f}")
        print(f"  正常类准确率: {normal_acc:.4f}")

    # 保存模型
    os.makedirs(os.path.dirname(args.model_output), exist_ok=True)
    classifier.save(args.model_output)
    print(f"\n模型保存到: {args.model_output}")

    # 加载同义词词典
    synonym_dict = load_synonym_dict()
    print(f"加载同义词词典: {len(synonym_dict)} 个词条")

    print("\n" + "=" * 60)
    print("训练完成!")
    print("=" * 60)

if __name__ == '__main__':
    main()
